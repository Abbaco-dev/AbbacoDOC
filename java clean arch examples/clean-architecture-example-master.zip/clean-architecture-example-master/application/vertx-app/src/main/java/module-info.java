open module slalom.example.vertx {
	requires vertx.core;
	requires vertx.web;
	requires slalom.example.config;
	requires jackson.annotations;
	requires slalom.example.usecase;
	requires slalom.example.controller;
}
