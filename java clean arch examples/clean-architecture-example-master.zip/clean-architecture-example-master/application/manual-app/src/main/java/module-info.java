module slalom.example.main {
	requires slalom.example.config;
	requires slalom.example.domain;
	requires slalom.example.usecase;
}
