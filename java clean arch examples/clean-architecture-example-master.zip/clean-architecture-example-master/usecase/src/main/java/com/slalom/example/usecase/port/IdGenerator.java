package com.slalom.example.usecase.port;

public interface IdGenerator {

	String generate();
}
