package com.slalom.example.usecase.port;

public interface PasswordEncoder {

	String encode(String str);
}
