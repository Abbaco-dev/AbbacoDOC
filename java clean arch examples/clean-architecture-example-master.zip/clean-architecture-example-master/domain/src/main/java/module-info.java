module slalom.example.domain {
	exports com.slalom.example.domain.entity;
}
