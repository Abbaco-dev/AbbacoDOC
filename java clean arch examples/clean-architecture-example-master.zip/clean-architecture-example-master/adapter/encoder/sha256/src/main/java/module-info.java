module slalom.example.encoder {
	exports com.slalom.example.encoder;

	requires slalom.example.usecase;
	requires org.apache.commons.codec;
}
