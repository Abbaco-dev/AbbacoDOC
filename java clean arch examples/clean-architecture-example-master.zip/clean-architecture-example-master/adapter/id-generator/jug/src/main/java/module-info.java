module slalom.example.jug {
	exports com.slalom.example.jug;

	requires slalom.example.usecase;
	requires java.uuid.generator;
}
