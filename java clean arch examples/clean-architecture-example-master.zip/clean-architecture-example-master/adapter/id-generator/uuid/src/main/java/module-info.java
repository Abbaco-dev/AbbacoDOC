module slalom.example.uuid {
	exports com.slalom.example.uuid;

	requires slalom.example.usecase;
}
