module slalom.example.db.hazelcast {
	exports com.slalom.example.db.hazelcast;

	requires slalom.example.domain;
	requires hazelcast;
	requires slalom.example.usecase;
}
