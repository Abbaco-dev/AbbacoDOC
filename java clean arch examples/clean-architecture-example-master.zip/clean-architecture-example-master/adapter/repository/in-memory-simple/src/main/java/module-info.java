module slalom.example.db.simple {
	exports com.slalom.example.db;

	requires slalom.example.domain;
	requires slalom.example.usecase;
}
