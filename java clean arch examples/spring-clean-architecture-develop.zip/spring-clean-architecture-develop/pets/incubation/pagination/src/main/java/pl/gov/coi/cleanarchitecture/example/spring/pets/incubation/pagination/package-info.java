/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 09.05.18
 */
@ParametersAreNonnullByDefault
package pl.gov.coi.cleanarchitecture.example.spring.pets.incubation.pagination;

import javax.annotation.ParametersAreNonnullByDefault;
