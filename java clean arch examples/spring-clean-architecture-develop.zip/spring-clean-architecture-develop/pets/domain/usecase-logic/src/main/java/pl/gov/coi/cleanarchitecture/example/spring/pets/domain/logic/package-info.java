/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 08.05.18
 */
@ParametersAreNonnullByDefault
package pl.gov.coi.cleanarchitecture.example.spring.pets.domain.logic;

import javax.annotation.ParametersAreNonnullByDefault;
