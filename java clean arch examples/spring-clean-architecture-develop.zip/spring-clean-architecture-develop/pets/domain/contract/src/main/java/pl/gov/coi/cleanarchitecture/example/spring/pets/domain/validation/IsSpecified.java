package pl.gov.coi.cleanarchitecture.example.spring.pets.domain.validation;

/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 14.05.18
 */
public interface IsSpecified {
  boolean isSpecified();
}
