SELECT count(p.id)
FROM PetData p
