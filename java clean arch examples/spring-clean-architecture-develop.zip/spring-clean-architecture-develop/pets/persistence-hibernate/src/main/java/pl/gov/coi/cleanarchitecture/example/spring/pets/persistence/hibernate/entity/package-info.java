/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 04.04.18
 */
@ParametersAreNonnullByDefault
package pl.gov.coi.cleanarchitecture.example.spring.pets.persistence.hibernate.entity;

import javax.annotation.ParametersAreNonnullByDefault;
