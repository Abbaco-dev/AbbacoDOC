/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 17.04.18
 */
@ParametersAreNonnullByDefault
package pl.gov.coi.cleanarchitecture.example.spring.pets.persistence.hibernate.mapper;

import javax.annotation.ParametersAreNonnullByDefault;
