/**
 * @author <a href="krzysztof.suszynski@wavesoftware.pl">Krzysztof Suszyński</a>
 * @since 2018-04-30
 */
@ParametersAreNonnullByDefault
package pl.gov.coi.cleanarchitecture.example.spring.pets.domain.model.configuration;

import javax.annotation.ParametersAreNonnullByDefault;
