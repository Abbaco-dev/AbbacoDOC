package pl.gov.coi.cleanarchitecture.example.spring.pets.persistence;

/**
 * @author <a href="mailto:krzysztof.suszynski@coi.gov.pl">Krzysztof Suszynski</a>
 * @since 26.04.18
 */
public interface ExampleDataPredicate {
  boolean shouldCreateExamples();
}
